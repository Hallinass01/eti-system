import json, os
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib import colors

LOCKED_SECTIONS = [
    "Horse Identification and Presenting Concern",
    "Intake Summary",
    "Eye Image Review",
    "Movement / Video Review",
    "Terrain Interpretation",
    "Progression Pattern",
    "What This Looks Like If Ignored",
    "ETI Conclusion",
    "Tom to Trainer",
    "Next-Step Framework",
]

def load_json(path):
    with open(path) as f:
        return json.load(f)

def compute_summary_scores(form, scoring_template):
    symptoms = set(form.get("symptoms", []))
    question = (form.get("primary_question") or "").lower()
    story = (form.get("horse_story") or "").lower()

    scores = {"hydration": 2, "gut": 2, "muscle": 2, "metabolic": 2}

    if "Slow recovery" in symptoms or "Flat performance" in symptoms:
        scores["hydration"] += 2
        scores["muscle"] += 2
    if "Digestive instability" in symptoms:
        scores["gut"] += 3
    if "Random/phantom lameness" in symptoms or "Stopping at fences" in symptoms:
        scores["muscle"] += 2
        scores["metabolic"] += 1
    if "Tight or anxious" in symptoms:
        scores["metabolic"] += 3
        scores["hydration"] += 1

    if "ulcer" in question or "manure" in story or "gut" in question:
        scores["gut"] += 2
    if "tight" in question or "hot" in story or "anxious" in question:
        scores["metabolic"] += 2
    if "fatigue" in question or "fade" in story or "not finishing" in question:
        scores["hydration"] += 2
        scores["muscle"] += 1

    final = {}
    for pillar, raw in scores.items():
        raw = min(raw, 10)
        band = "Stable"
        for span, label in scoring_template[pillar]["bands"].items():
            start, end = [int(x) for x in span.split("-")]
            if start <= raw <= end:
                band = label
                break
        final[pillar] = {"score": raw, "band": band}
    return final

def build_locked_sections(form, report_rules):
    horse = form.get("horse_name") or "This horse"
    discipline = form.get("discipline") or "general performance"
    question = form.get("primary_question") or "No primary question was entered."
    story = form.get("horse_story") or "No horse story was entered."
    symptoms = ", ".join(form.get("symptoms", [])) or "No symptom boxes were selected."
    eye_count = len(form.get("files", {}).get("eye_photos", []))
    body_count = len(form.get("files", {}).get("body_photos", []))
    video_count = len(form.get("files", {}).get("videos", []))
    scores = form.get("scores", {})

    return {
        "Horse Identification and Presenting Concern":
            f"{horse} was submitted as a {discipline} case. The primary question entered was: {question} "
            f"This report preserves the locked ETI order and is designed to frame the horse as a whole-system terrain case, not a loose collection of unrelated symptoms.",

        "Intake Summary":
            f"Reported symptoms include: {symptoms} The history provided reads as follows: {story} "
            f"Feed, supplementation, water behavior, travel, surface, and turnout details should be treated as biologic inputs that shape the horse’s terrain, not as background details to be ignored.",

        "Eye Image Review":
            f"{eye_count} eye image file(s) were submitted. In the live ETI system this section remains fixed in place and is where the eye review language, pattern references, and image quality qualifiers are inserted. "
            f"The final production version should never omit this section even when better eye photos are still needed.",

        "Movement / Video Review":
            f"{body_count} body photo file(s) and {video_count} video file(s) were submitted. This section is reserved for the locked movement interpretation format, including symmetry, stride pattern, compensation language, and improve → plateau → regress commentary where supported.",

        "Terrain Interpretation":
            f"This horse is not presenting with a random problem. This is a pattern. "
            f"The intake suggests interacting terrain pressure across hydration, gut, muscle, and metabolic regulation. "
            f"Current score summary indicates hydration {scores['hydration']['score']}/10 ({scores['hydration']['band']}), gut {scores['gut']['score']}/10 ({scores['gut']['band']}), muscle {scores['muscle']['score']}/10 ({scores['muscle']['band']}), and metabolic {scores['metabolic']['score']}/10 ({scores['metabolic']['band']}). "
            f"The final ETI voice in this section should be explanatory, physiologic, and confident.",

        "Progression Pattern":
            f"The point of this section is to state whether the horse appears to be improving, plateauing, or regressing. "
            f"It should describe how compensation may be masking the true case and where the pattern is most likely headed if current terrain pressure is not relieved.",

        "What This Looks Like If Ignored":
            f"If this terrain pattern continues without correction, the likely direction is greater inconsistency, reduced confidence, more obvious compensation, and eventual breakdown in performance quality. "
            f"This section exists to create clear foresight, not sales pressure.",

        "ETI Conclusion":
            f"The ETI conclusion should synthesize the full case and state clearly what is most likely driving the present pattern. "
            f"It should end with disciplined confidence and should never sound vague, padded, or generic.",

        "Tom to Trainer":
            f"If this were mine, I would want this section to feel direct, plainspoken, and practical. "
            f"It should read like Tom speaking to the trainer about what matters right now, what not to ignore, and what this horse is really telling them.",

        "Next-Step Framework":
            f"This section should preserve the same ETI order every time: immediate priorities, monitoring priorities, and follow-up review needs. "
            f"It should remain complete in wording and should not be condensed.",
    }

def render_pdf_report(case_id, form, report_dir):
    os.makedirs(report_dir, exist_ok=True)
    path = os.path.join(report_dir, f"{case_id}.pdf")

    doc = SimpleDocTemplate(path, pagesize=letter, rightMargin=30, leftMargin=30, topMargin=30, bottomMargin=30)
    styles = getSampleStyleSheet()

    title = ParagraphStyle("title", parent=styles["Title"], fontSize=21, leading=24, textColor=colors.HexColor("#0B1530"))
    sub = ParagraphStyle("sub", parent=styles["Heading2"], fontSize=10.5, leading=13, textColor=colors.HexColor("#8A6A33"))
    section = ParagraphStyle("section", parent=styles["Heading3"], fontSize=12, leading=14, textColor=colors.HexColor("#0B1530"), spaceAfter=5, spaceBefore=4)
    body = ParagraphStyle("body", parent=styles["BodyText"], fontSize=9.25, leading=12, textColor=colors.HexColor("#1B2330"))
    callout = ParagraphStyle("callout", parent=styles["BodyText"], fontSize=9.5, leading=12, textColor=colors.HexColor("#0B1530"))

    story = []
    story.append(Paragraph("Equine Terrain Institute", title))
    story.append(Paragraph("The New Science of the Modern Horse: The Terrain Revolution", sub))
    story.append(Spacer(1, 8))

    meta_rows = [
        ["Horse", form.get("horse_name",""), "Discipline", form.get("discipline","")],
        ["Owner", form.get("owner_name",""), "Trainer", form.get("trainer_name","")],
        ["Age", form.get("age",""), "Breed / Sex", f"{form.get('breed','')} / {form.get('sex','')}"],
    ]
    meta = Table(meta_rows, colWidths=[60, 175, 70, 205])
    meta.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), colors.HexColor("#F1F5FB")),
        ("GRID", (0,0), (-1,-1), 0.4, colors.HexColor("#7A8FB1")),
        ("FONTNAME", (0,0), (-1,-1), "Helvetica"),
        ("FONTNAME", (0,0), (0,-1), "Helvetica-Bold"),
        ("FONTNAME", (2,0), (2,-1), "Helvetica-Bold"),
        ("TEXTCOLOR", (0,0), (-1,-1), colors.HexColor("#1B2330")),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
    ]))
    story.append(meta)
    story.append(Spacer(1, 10))

    scores = form["scores"]
    rows = [["Pillar", "Score", "Status", "Interpretation"]]
    interp = {
        "hydration": "Fluid distribution and performance reserve",
        "gut": "Digestive terrain and hindgut stability",
        "muscle": "Load, fatigue, and compensation pressure",
        "metabolic": "Nervous system and regulatory strain",
    }
    for pillar in ["hydration", "gut", "muscle", "metabolic"]:
        rows.append([pillar.title(), str(scores[pillar]["score"]), scores[pillar]["band"], interp[pillar]])
    table = Table(rows, colWidths=[95, 55, 110, 250])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#0B1530")),
        ("TEXTCOLOR", (0,0), (-1,0), colors.white),
        ("BACKGROUND", (0,1), (-1,-1), colors.HexColor("#EEF3FA")),
        ("GRID", (0,0), (-1,-1), 0.5, colors.HexColor("#7A8FB1")),
        ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
        ("FONTNAME", (0,1), (0,-1), "Helvetica-Bold"),
        ("VALIGN", (0,0), (-1,-1), "TOP"),
    ]))
    story.append(table)
    story.append(Spacer(1, 10))

    story.append(Paragraph("<b>Summary of Findings</b>", section))
    story.append(Paragraph("This horse is not presenting with a random problem. This is a pattern.", callout))
    story.append(Spacer(1, 6))

    for name in LOCKED_SECTIONS:
        story.append(Paragraph(name, section))
        story.append(Paragraph(form["locked_sections"][name].replace("\n","<br/>"), body))
        story.append(Spacer(1, 7))

    doc.build(story)
    return path